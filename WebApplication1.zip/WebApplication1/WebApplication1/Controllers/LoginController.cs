﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        Random rng = new Random();
        Guid id;
        string email = "";
        string name = "";
        string password = "";
        bool deleted;
        DateTime deleted_at;
        DateTime updated_at;
        static List<User> _users = new List<User>();

        [HttpPost]
        public IActionResult Login(string eMail, string user, string pass)
        {
            email = eMail;
            password = pass;
            name = user;

            return Ok("code 200");
        }

        [HttpGet]
        [Route("USERS")]

        public List <User> Users()
        {
            return _users;
        }

        [HttpGet]
        [Route("USERS/1")]

        public IActionResult user1(Guid id)
        {
            foreach (var item in _users)
            {
                if (item.id == id)
                {
                    return Ok(item);
                }
            }
            return NotFound("user not found");
        }

        [HttpGet]
        [Route($"UserSpecific")]

        public IActionResult user2(string name, ushort age)
        {
            foreach (var user in _users)
            {
                if (user.name == name && user.age == age)
                {
                    return Ok(user);
                }
            }
            return NotFound("user no found");
        }

        [HttpPut]
        [Route("Create")]
        public IActionResult Create(string email, string name, string password)
        {
            int tempInt = rng.Next(ushort.MinValue + 1, ushort.MaxValue - 1);
            ushort tempUshort = Convert.ToUInt16(tempInt);
            id = Guid.NewGuid();
            deleted = false;
            deleted_at = DateTime.Now;
            updated_at = DateTime.Now;

            User newUser = new User(id, email, name, password, tempUshort, deleted, deleted_at, updated_at);

            _users.Add(newUser);

            return Ok("code 200");
        }

        [HttpPut]
        [Route("Update")]

        public IActionResult Update(Guid id, string email, string name, string password)
        {
            Guid tempId = _users[0].id;
            Console.WriteLine(tempId);

            foreach (var item in _users)
            {
                if (id == item.id && email != "")
                {
                    item.email = email;
                    updated_at = DateTime.Now;
                }
                else
                {
                    return NotFound("error code 401");
                }
                if (id == item.id && name != "")
                {
                    item.name = name;
                    updated_at = DateTime.Now;
                }
                else
                {
                    return NotFound("error code 401");
                }
                if (id == item.id && password != "")
                {
                    item.password = password;
                    updated_at = DateTime.Now;
                }
                else
                {
                    return NotFound("error code 401");
                }
            }
            return Ok("code 200");
        }

        [HttpDelete]
        [Route("delete")]
        public IActionResult Delete(Guid id)
        {
            foreach (var item in _users)
            {
                if (item.id == id)
                {
                    _users.Remove(item);
                    return Ok("sikerült");
                }
            }
            return NotFound("Nincs ilyen elem");
        }
    }
}
