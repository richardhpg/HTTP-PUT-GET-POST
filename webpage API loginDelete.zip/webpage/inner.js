let menuButton = document.getElementById("menuColButton")
let logOut = document.getElementById("logOutBtn")
let menuCol = document.getElementById("menuCol")
let colStyle = window.getComputedStyle(menuCol)
let account = document.getElementById("felhasznalo")
let accountList = document.getElementById("accountList")

window.addEventListener("DOMContentLoaded", async () => {
    let response = await fetch(`https://localhost:7262/Login/USERS`)
    let data = await response.json();
    console.log(data[0])

    const cardItem = document.createElement("div");
    cardItem.classList.add("card");
    cardItem.classList.add("todo");
    cardItem.id = data[0].id;
    const cardBody = document.createElement("div");
    cardBody.classList.add("card-body");
    const cardTitle = document.createElement("h5");
    cardTitle.classList.add("card-title");
    cardTitle.innerText = data[0].name;
    const cardText = document.createElement("p");
    cardText.classList.add("card-text");
    cardText.innerText = `email: ${data[0].email}`;
    cardText.innerText += "; "
    cardText.innerText += `id: ${data[0].id}`;
    cardText.classList.add("jani");
    const btnWrapper = document.createElement("span");
    btnWrapper.id = "btnWrapper";
    const editButton = document.createElement("span");
    editButton.classList.add("btn");
    editButton.classList.add("editBtn");
    editButton.id = data[0].id;
    editButton.innerText = "edit";
    editButton.classList.add("mx-2")
    const deleteButton = document.createElement("span");
    deleteButton.classList.add("btn-close");
    deleteButton.classList.add("deleteBtn");
    deleteButton.id = data[0].id;
    deleteButton.classList.add("mx-2")

    btnWrapper.appendChild(editButton);
    btnWrapper.appendChild(deleteButton);
    cardText.appendChild(btnWrapper);
    cardBody.appendChild(cardTitle);
    cardBody.appendChild(cardText);
    cardItem.appendChild(cardBody);
    accountList.appendChild(cardItem);

    editButton.addEventListener("click", function () {

        const nameElement = cardTitle;
        const descElement = cardText.childNodes[0];


        const nameInput = document.createElement("input");
        nameInput.type = "text";
        nameInput.value = nameElement.innerText;
        nameInput.classList.add("form-control", "mb-2");

        const descInput = document.createElement("textarea");
        descInput.value = descElement.textContent;
        descInput.classList.add("form-control");

        cardBody.replaceChild(nameInput, nameElement);
        cardText.replaceChild(descInput, descElement);

        editButton.style.display = "none";

        const saveButton = document.createElement("span");
        saveButton.classList.add("btn");
        saveButton.innerText = "save";
        btnWrapper.appendChild(saveButton);
        saveButton.style.display = "inline-block"

        saveButton.addEventListener("click", function () {
            let taskIndex = tasks.findIndex(t => t.taskId == task.taskId);
            if (taskIndex !== -1) {
                tasks[taskIndex].taskName = nameInput.value;
                tasks[taskIndex].taskDesc = descInput.value;
            }

            localStorage.setItem("tasks", JSON.stringify(tasks));

            nameElement.innerText = nameInput.value;
            descElement.textContent = descInput.value;

            cardBody.replaceChild(nameElement, nameInput);
            cardText.replaceChild(descElement, descInput);

            editButton.style.display = "inline-block";
            doneButton.style.display = "inline-block";

            btnWrapper.removeChild(saveButton);
        });
    });

    deleteButton.addEventListener("click", async () => {
        let response = await fetch(`https://localhost:7262/Login/delete/${deleteButton.id}`, { method: "DELETE" })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Delete failed");
                }
                return response.text();
            })
            .catch(error => {
                alert("error" + error.message)
            });
        accountList.removeChild(cardItem)
    })
})


menuButton.addEventListener("click", function () {
    if (colStyle.display == "none") {
        menuCol.style = "display:flex;"
    }
    else if (colStyle.display == "flex") {
        menuCol.style = "display:none !important;"
    }
})

logOut.addEventListener("click", function () {
    localStorage.removeItem("name")
})

function safetyNet() {
    console.log(localStorage.getItem("name"))
    if (localStorage.getItem("name") != "admin" && localStorage.getItem("name") != "user") {
        window.location.replace("index.html")
    }
}

function userOut() {
    account.innerHTML = localStorage.getItem("name")
    document.getElementById("userOut").innerHTML = localStorage.getItem("name")
}