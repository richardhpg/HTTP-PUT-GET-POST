let user = document.getElementById("user")
let password = document.getElementById("password")
let alert = document.getElementById("alert")
let userField = document.getElementById("userField")
let passwordField = document.getElementById("passwordField")
let passwordToggler = document.getElementById("togglePassword")

async function loginSubmit()
{
    let response = await fetch(`https://localhost:7262/Login/login:${user.value}&&${password.value}`, {method: "POST"})
    console.log(response)
    if ((await response).ok) {
        window.location.replace("mainpage.html")
        localStorage.setItem("name","admin")
    }
    else
    {
        console.log("asd")
        alert.style = "display: block;"
    }

    // if (user.value == "admin" && password.value == "12345") 
    // {
    //     window.location.replace("mainpage.html")
    //     localStorage.setItem("name","admin")
    // }
    // else if (user.value == "user" && password.value == "12345")
    // {
    //     window.location.replace("mainpage.html")
    //     localStorage.setItem("name","user")
    // }
    // else
    // {
    //     console.log("asd")
    //     alert.style = "display: block;"
    // }
}

user.addEventListener("focus", function () 
{
    console.log("user")
    userField.style = "border-color: #3A7EF9 !important;"
})

password.addEventListener("focus", function () 
{
    console.log("pass")
    passwordField.style = "border-color: #3A7EF9 !important;"
})

user.addEventListener("blur", function () 
{
    console.log("userBlur")
    userField.style = "border-color: rgb(100, 100, 100) !important;"
})

password.addEventListener("blur", function () 
{
    console.log("passBlur")
    passwordField.style = "border-color: rgb(100, 100, 100) !important;"
})

function togglePassword()
{
     if (password.type == "password") 
    {
        password.type = "text"   
    }
    else
    {
        password.type = "password"
    }
}