﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ValamiController : ControllerBase
    {
        [HttpGet]
        public string Valami()
        {
            return "Hello World";
        }
        [HttpGet]
        [Route("Valami2")]
        public string Valami2()
        {
            return "Hello World2";
        }
    }
}
