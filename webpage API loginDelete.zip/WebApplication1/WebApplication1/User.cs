﻿using Microsoft.VisualBasic.FileIO;

namespace WebApplication1
{
    public class User 
    {
        public User(string email , string name, string password, ushort age, bool deleted, DateTime? deleted_at, DateTime? updated_at)
        {
            this.id = Guid.NewGuid();
            this.email = email;
            this.name = name;
            this.password = password;
            this.age = age;
            Deleted = deleted;
            Deleted_at = deleted_at;
            Updated_at = updated_at;
        }

        public Guid id { get; set; }
        public string email { get; set; } 
        public string name { get; set; }
        public string password { get; set; }
        public ushort age { get; set; }
        public bool Deleted { get; set; }
        public DateTime? Deleted_at { get; set; }
        public DateTime? Updated_at { get; set; }
    }
}
