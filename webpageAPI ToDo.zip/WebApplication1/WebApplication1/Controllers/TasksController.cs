﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        public static List <Task> list = new List <Task> ();

        [HttpGet]
        [Route("tasks")]

        public List<Task> tasks()
        { 
            return list;
        }

        [HttpPut]
        [Route("create")]

        public IActionResult create(TaskDto taskDto)
        { 
            Guid id = Guid.NewGuid();
            Task task = new Task(taskDto.name, taskDto.description, id, false);
            list.Add (task);
            return Ok(task);
        }

        [HttpPut]
        [Route("update/{id}")]

        public IActionResult update(Guid id,[FromBody] TaskDto taskDto)
        {
            var task = list.FirstOrDefault(u => u.id == id);
            if (task == null)
            {
                return NotFound("Error 404: User not found.");
            }

            bool updated = false;

            if (!string.IsNullOrWhiteSpace(taskDto.name) && taskDto.name != "null")
            {
                task.name = taskDto.name;
                updated = true;
            }

            if (!string.IsNullOrWhiteSpace(taskDto.description) && taskDto.description != "null")
            {
                task.description = taskDto.description;
                updated = true;
            }

            if (updated)
            {
                return Ok("Code 200: Task updated.");
            }

            return BadRequest("Error 400: No valid data provided for update.");
        }

        [HttpPut]
        [Route("completed/{id}")]

        public IActionResult completed(Guid id)
        {
            var task = list.FirstOrDefault(task => task.id == id);
            task.isComplete = true;
            if (task.isComplete)
            {
                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        [Route("delete/{id}")]

        public IActionResult delete(Guid id)
        {
            var task = list.FirstOrDefault(u => u.id == id);
            list.Remove(task);
            return Ok();
        }
    }
}
