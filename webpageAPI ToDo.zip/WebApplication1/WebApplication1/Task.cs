﻿namespace WebApplication1
{
    public class Task
    {
        public Task(string name, string description, Guid id , bool isComplete)
        {
            this.name = name;
            this.description = description;
            this.id = id;
            this.isComplete = isComplete;
        }

        public string name { get; set; }
        public string description { get; set; }
        public Guid id { get; set; }
        public bool isComplete { get; set; }
    }
    public class TaskDto
    {
        public string name { get; set; }
        public string description { get; set; }
    }
}
