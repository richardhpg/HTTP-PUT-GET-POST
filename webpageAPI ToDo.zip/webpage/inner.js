let menuButton = document.getElementById("menuColButton")
let logOut = document.getElementById("logOutBtn")
let menuCol = document.getElementById("menuCol")
let colStyle = window.getComputedStyle(menuCol)
let account = document.getElementById("felhasznalo")
let accountList = document.getElementById("accountList")

window.addEventListener("DOMContentLoaded", async () => {
    let response = await fetch(`https://localhost:7262/Login/USERS`)
    let data = await response.json();
    console.log(data[0])

    const cardItem = document.createElement("div");
    cardItem.classList.add("card");
    cardItem.classList.add("todo");
    cardItem.id = data[0].id;

    const cardBody = document.createElement("div");
    cardBody.classList.add("card-body");

    const cardTitle = document.createElement("h5");
    cardTitle.classList.add("card-title");
    cardTitle.innerText = data[0].name;

    const cardText = document.createElement("p");
    cardText.classList.add("card-text");
    cardText.classList.add("jani");

    const emailWrapper = document.createElement("span")

    const emailTextSpan = document.createElement("span")
    emailTextSpan.innerText = "email: ";

    const emailSpan = document.createElement("span")
    emailSpan.innerText = data[0].email;

    const emailPasswordDivider = document.createElement("br")

    const passwordWrapper = document.createElement("span")
    const passwordTextSpan = document.createElement("span")
    passwordTextSpan.innerText = "password: "
    const passwordSpan = document.createElement("span")
    passwordSpan.innerText = data[0].password

    const passwordIdDivider = document.createElement("br")

    const idWrapper = document.createElement("span")
    const idTextSpan = document.createElement("span")
    idTextSpan.innerText = "id: "
    const idSpan = document.createElement("span")
    idSpan.innerText = data[0].id;

    const btnWrapper = document.createElement("span");
    btnWrapper.id = "btnWrapper";

    const editButton = document.createElement("span");
    editButton.classList.add("btn");
    editButton.classList.add("editBtn");
    editButton.id = data[0].id;
    editButton.innerText = "edit";
    editButton.classList.add("mx-2")

    const deleteButton = document.createElement("span");
    deleteButton.classList.add("btn-close");
    deleteButton.classList.add("deleteBtn");
    deleteButton.id = data[0].id;
    deleteButton.classList.add("mx-2")

    btnWrapper.appendChild(editButton);
    btnWrapper.appendChild(deleteButton);
    emailWrapper.appendChild(emailTextSpan);
    emailWrapper.appendChild(emailSpan);
    idWrapper.appendChild(idTextSpan);
    idWrapper.appendChild(idSpan);
    cardText.appendChild(emailWrapper);
    cardText.appendChild(emailPasswordDivider);  
    cardText.appendChild(idWrapper)
    cardText.appendChild(btnWrapper);
    cardBody.appendChild(cardTitle);
    cardBody.appendChild(cardText);
    cardItem.appendChild(cardBody);
    accountList.appendChild(cardItem);

    editButton.addEventListener("click", function () {

        const nameElement = cardTitle;
        const emailElement = emailWrapper.childNodes[1];
        const passElement = passwordWrapper.childNodes[1];


        const nameInput = document.createElement("textarea");
        nameInput.value = nameElement.innerText;
        nameInput.classList.add("form-control", "mb-2");
        let previousName = nameElement.innerText;

        const emailInput = document.createElement("textarea");
        emailInput.value = emailSpan.textContent;
        emailInput.classList.add("form-control");
        let previousEmail = emailSpan.textContent;

        cardBody.replaceChild(nameInput, nameElement);
        emailWrapper.replaceChild(emailInput, emailElement);

        editButton.style.display = "none";

        const saveButton = document.createElement("span");
        saveButton.classList.add("btn");
        saveButton.innerText = "save";
        btnWrapper.appendChild(saveButton);
        saveButton.style.display = "inline-block"

        saveButton.addEventListener("click", async () => {

            if (previousEmail != emailInput.value || previousName != nameInput.value) {
                let response = await fetch(`https://localhost:7262/Login/Update/${data[0].id}`, { method: "PUT" , body: JSON.stringify({email: emailInput.value, name: nameInput.value}), headers: {"Content-Type": "application/json"}})
                    .then(response => {
                        if (!response.ok) {
                            throw new Error("Update failed");
                        }
                        return response.text();
                    })
                    .catch(error => {
                        alert("error: " + error.message)
                    });

                nameElement.innerText = nameInput.value;
                emailElement.textContent = emailInput.value;

                cardBody.replaceChild(nameElement, nameInput);
                emailWrapper.replaceChild(emailElement, emailInput);

                editButton.style.display = "inline-block";

                btnWrapper.removeChild(saveButton);
            }
        });
    });

    deleteButton.addEventListener("click", async () => {
        let response = await fetch(`https://localhost:7262/Login/delete/${deleteButton.id}`, { method: "DELETE" })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Delete failed");
                }
                return response.text();
            })
            .catch(error => {
                alert("error" + error.message)
            });
        accountList.removeChild(cardItem)
    })
})


menuButton.addEventListener("click", function () {
    if (colStyle.display == "none") {
        menuCol.style = "display:flex;"
    }
    else if (colStyle.display == "flex") {
        menuCol.style = "display:none !important;"
    }
})

logOut.addEventListener("click", function () {
    localStorage.removeItem("name")
})

function safetyNet() {
    console.log(localStorage.getItem("name"))
    if (localStorage.getItem("name") != "admin" && localStorage.getItem("name") != "user") {
        window.location.replace("index.html")
    }
}

function userOut() {
    account.innerHTML = localStorage.getItem("name")
    document.getElementById("userOut").innerHTML = localStorage.getItem("name")
}