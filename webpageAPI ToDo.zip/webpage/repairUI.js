let menuButton = document.getElementById("menuColButton");
let logOut = document.getElementById("logOutBtn");
let menuCol = document.getElementById("menuCol");
let account = document.getElementById("felhasznalo");
let dateYear = document.getElementById("dateYY");
let dateMonth = document.getElementById("dateMM");
let dateDay = document.getElementById("dateDD");
let paperID = document.getElementById("paperId");
let workers = document.getElementsByClassName("workers");
let workStart = document.getElementsByClassName("workStart");
let workEnd = document.getElementsByClassName("workEnd");
let berendezes = document.getElementById("berendezes");
let errorName = document.getElementById("errorName");
let workDesc = document.getElementById("workDesc");
let suggestion = document.getElementById("suggestion");
let usedMaterials = document.getElementById("usedMaterials");
let orderedMaterials = document.getElementById("orderedMaterials");
let materialsComment = document.getElementById("materialComment");
let conveyor = document.getElementById("conveyor");
let cleaningNeeded = document.getElementById("cleaningNeeded");
let reciever = document.getElementById("reciever");

let submitButton = document.getElementById("submitButton");

submitButton.addEventListener("click", function () {

    let names = [];
    for (let i = 0; i < workers.length; i++) {

        names.push(workers[i].value);
        console.log(names[i])
        console.log(workers[i].value)
    }

    let startTimes = []
    for (let i = 0; i < workStart.length; i++) {

        startTimes.push(workStart[i].value);
    }

    let endTimes = []
    for (let i = 0; i < workEnd.length; i++) {

        endTimes.push(workEnd[i].value);
    }

    dateYear = document.getElementById("dateYY");
    dateMonth = document.getElementById("dateMM");
    dateDay = document.getElementById("dateDD");
    paperID = document.getElementById("paperId");
    workers = document.getElementsByClassName("workers");
    workStart = document.getElementsByClassName("workStart");
    workEnd = document.getElementsByClassName("workEnd");
    berendezes = document.getElementById("berendezes");
    errorName = document.getElementById("errorName");
    workDesc = document.getElementById("workDesc");
    suggestion = document.getElementById("suggestion");
    usedMaterials = document.getElementById("usedMaterials");
    orderedMaterials = document.getElementById("orderedMaterials");
    materialsComment = document.getElementById("materialComment");
    conveyor = document.getElementById("conveyor");
    cleaningNeeded = document.getElementById("cleaningNeeded");
    reciever = document.getElementById("reciever");

    let newMunkalap = new Munkalap(dateYear.value, dateMonth.value, dateDay.value, paperID.value, names, startTimes, endTimes, berendezes.value, errorName.value, workDesc.value, suggestion.value, usedMaterials.value, orderedMaterials.value, materialsComment.value, conveyor.value, cleaningNeeded.value, reciever.value);
    localStorage.setItem("munkalap", JSON.stringify(newMunkalap));

})

class Munkalap {
    dateYY;
    dateMM;
    dateDD;
    id;
    names = [];
    workStart = [];
    workEnd = [];
    berendezes;
    errorName;
    workDesc;
    suggestion;
    usedMaterials;
    orderedMaterials;
    materialsComment;
    conveyor;
    cleaningNeeded;
    reciever;

    constructor(dateYY, dateMM, dateDD, id, names, workStart, workEnd, berendezes, errorName, workDesc, suggestion, usedMaterials, orderedMaterials, materialsComment, conveyor, cleaningNeeded, reciever) {
        this.dateYY = dateYY;
        this.dateMM = dateMM;
        this.dateDD = dateDD;
        this.id = id;
        this.names = names;
        this.workStart = workStart;
        this.workEnd = workEnd;
        this.berendezes = berendezes;
        this.errorName = errorName;
        this.workDesc = workDesc;
        this.suggestion = suggestion;
        this.usedMaterials = usedMaterials;
        this.orderedMaterials = orderedMaterials;
        this.materialsComment = materialsComment;
        this.conveyor = conveyor;
        this.cleaningNeeded = cleaningNeeded;
        this.reciever = reciever;
    }
    get dateYY() {
        return this.dateYY;
    }
    get dateMM() {
        return this.dateMM;
    }
    get dateDD() {
        return this.dateDD;
    }
    get id() {
        return this.id;
    }
    get names() {
        return this.names;
    }
    get workStart() {
        return this.workStart;
    }
    get workEnd() {
        return this.workEnd;
    }
    get berendezes() {
        return this.berendezes;
    }
    get errorName() {
        return this.errorName;
    }
    get workDesc() {
        return this.workDesc;
    }
    get suggestion() {
        return this.suggestion;
    }
    get usedMaterials() {
        return this.usedMaterials;
    }
    get orderedMaterials() {
        return this.orderedMaterials;
    }
    get materialsComment() {
        return this.materialsComment;
    }
    get conveyor() {
        return this.conveyor;
    }
    get cleaningNeeded() {
        return this.cleaningNeeded;
    }
    get reciever() {
        return this.reciever;
    }
}

window.addEventListener("DOMContentLoaded", function () {
    let temp = JSON.parse(localStorage.getItem("munkalap"));

    dateYear.value = temp.dateYY;
    dateMonth.value = temp.dateMM;
    dateDay.value = temp.dateDD;
    paperID.value = temp.id;
    for (let i = 0; i < temp.names.length; i++) {
        for (let j = 0; j < workers.length; j++) {
            if (i == j) {
                workers[j].value = temp.names[i];
            }
        }
    }

    for (let i = 0; i < temp.workStart.length; i++) {
        if (workStart[i]) {
            workStart[i].value = temp.workStart[i];
        }
    }

    for (let i = 0; i < temp.workEnd.length; i++) {
        if (workEnd[i]) {
            workEnd[i].value = temp.workEnd[i];
        }
    }

    berendezes.value = temp.berendezes;
    errorName.value = temp.errorName;
    workDesc.value = temp.workDesc;
    suggestion.value = temp.suggestion;
    usedMaterials.value = temp.usedMaterials;
    orderedMaterials.value = temp.orderedMaterials;
    materialsComment.value = temp.materialsComment;
    conveyor.value = temp.conveyor;
    cleaningNeeded.value = temp.cleaningNeeded;
    reciever.value = temp.reciever;
})

menuButton.addEventListener("click", function () {
    let colStyle = window.getComputedStyle(menuCol);
    if (colStyle.display == "none") {
        menuCol.style = "display:flex;"
    }
    else if (colStyle.display == "flex") {
        menuCol.style = "display:none !important;"
    }
})

logOut.addEventListener("click", function () {
    localStorage.removeItem("name")
})

function safetyNet() {
    console.log(localStorage.getItem("name"))
    if (localStorage.getItem("name") != "admin" && localStorage.getItem("name") != "user") {
        window.location.replace("index.html")
    }
}

function userOut() {
    account.innerHTML = localStorage.getItem("name")
    document.getElementById("userOut").innerHTML = localStorage.getItem("name")
}