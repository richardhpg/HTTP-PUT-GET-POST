let menuButton = document.getElementById("menuColButton")
let logOut = document.getElementById("logOutBtn")
let menuCol = document.getElementById("menuCol")
let colStyle = window.getComputedStyle(menuCol)
let account = document.getElementById("felhasznalo")

menuButton.addEventListener("click", function () {
    if (colStyle.display == "none") {
        menuCol.style = "display:flex;"
    }
    else if (colStyle.display == "flex") {
        menuCol.style = "display:none !important;"
    }
})

logOut.addEventListener("click", function () {
    localStorage.removeItem("name")
})

function safetyNet() {
    console.log(localStorage.getItem("name"));
    if (localStorage.getItem("name") != "admin" && localStorage.getItem("name") != "user") {
        window.location.replace("index.html");
    }
}

function userOut() {
    account.innerHTML = localStorage.getItem("name");
    document.getElementById("userOut").innerHTML = localStorage.getItem("name");
}

const taskAddName = document.getElementById("taskAddName");
const taskAddDesc = document.getElementById("taskAddDesc");
const taskAddBtn = document.getElementById("taskAddBtn");
const todoTaskList = document.getElementById("todoTaskList");
const completedTaskList = document.getElementById("completedTaskList")
let completedBtns = document.getElementsByClassName("completedBtn");
let editBtns = document.getElementsByClassName("editBtn");
let deleteBtns = document.getElementsByClassName("deleteBtn");
let deleteBtnIds = 0;


window.addEventListener("DOMContentLoaded", async () => {
    let response = await fetch("https://localhost:7262/Tasks/tasks");
    let data = await response.json();
    console.log(data)
    let tasks = data;
    for (let i = 0; i < tasks.length; i++) {
        listItemAdder(tasks[i])
    }
})

function listItemAdder(task) {

    if (task.isComplete == false) {
        const listItem = document.createElement("li");
        listItem.id = task.id;
        const cardItem = document.createElement("div");
        cardItem.classList.add("card");
        cardItem.classList.add("todo");
        const cardBody = document.createElement("div");
        cardBody.classList.add("card-body");
        const cardTitle = document.createElement("h5");
        cardTitle.classList.add("card-title");
        cardTitle.innerText = task.name;
        const cardText = document.createElement("p");
        cardText.classList.add("card-text");
        cardText.innerText = task.description;
        cardText.classList.add("jani");
        const doneButton = document.createElement("span");
        doneButton.classList.add("btn");
        doneButton.classList.add("completedBtn");
        doneButton.id = task.id;
        doneButton.innerText = "done";
        const editButton = document.createElement("span");
        editButton.classList.add("btn");
        editButton.classList.add("editBtn");
        editButton.id = task.id;
        editButton.innerText = "edit";
        const deleteButton = document.createElement("span");
        deleteButton.classList.add("btn-close");
        deleteButton.classList.add("deleteBtn");
        deleteButton.id = task.id;

        cardText.appendChild(doneButton);
        cardText.appendChild(editButton);
        cardText.appendChild(deleteButton);
        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);
        cardItem.appendChild(cardBody);
        listItem.appendChild(cardItem);

        deleteButton.addEventListener("click", async () => {
            let response = await fetch(`https://localhost:7262/Tasks/delete/${listItem.id}`, { method: "DELETE" })
            console.log(response)
            listItem.style.animation = "slide-out 0.5s ease-in-out"
            setTimeout(() => {
                todoTaskList.removeChild(listItem)
                // localStorage.setItem("tasks", JSON.stringify(tasks));
            }, 400);
        })
        editButton.addEventListener("click", async () => {

            const nameElement = cardTitle;
            const descElement = cardText.childNodes[0];


            const nameInput = document.createElement("input");
            nameInput.type = "text";
            nameInput.value = nameElement.innerText;
            nameInput.classList.add("form-control", "mb-2");

            const descInput = document.createElement("textarea");
            descInput.value = descElement.textContent;
            descInput.classList.add("form-control");

            cardBody.replaceChild(nameInput, nameElement);
            cardText.replaceChild(descInput, descElement);

            editButton.style.display = "none";
            doneButton.style.display = "none";

            const saveButton = document.createElement("span");
            saveButton.classList.add("btn", "btn-success", "ms-2");
            saveButton.innerText = "save";

            cardText.appendChild(saveButton);

            saveButton.addEventListener("click", async () => {

                let response = await fetch(`https://localhost:7262/Tasks/update/${task.id}`, { method: "PUT", body: JSON.stringify({ name: nameInput.value, description: descInput.value }), headers: { "Content-Type": "application/json" } })

                nameElement.innerText = nameInput.value;
                descElement.textContent = descInput.value;

                cardBody.replaceChild(nameElement, nameInput);
                cardText.replaceChild(descElement, descInput);

                editButton.style.display = "inline-block";
                doneButton.style.display = "inline-block";

                cardText.removeChild(saveButton);
            });
        });
        doneButton.addEventListener("click", async () => {
            let response = await fetch(`https://localhost:7262/Tasks/completed/${task.id}`, {method: "PUT"})
            let tasks = await (await fetch("https://localhost:7262/Tasks/tasks")).json()

            listItem.style.animation = "slide-done 0.5s ease-in-out"

            setTimeout(() => {
                todoTaskList.removeChild(listItem);
                const currentTask = tasks.find(task => task.id == doneButton.id);
                listItem.remove();
                currentTask.isComplete = true;

                // localStorage.setItem("tasks", JSON.stringify(tasks))
                listItemAdder(currentTask)
            }, 400);
        })

        listItem.style.animation = "slide-in 0.5s ease-in-out"
        setTimeout(() => {
            todoTaskList.insertBefore(listItem, todoTaskList.childNodes[0]);
        }, 400);
    }
    else if (task.isComplete == true) {
        const listItem = document.createElement("li");
        listItem.id = task.id;
        const cardItem = document.createElement("div");
        cardItem.classList.add("card");
        cardItem.classList.add("todo");
        const cardBody = document.createElement("div");
        cardBody.classList.add("card-body");
        const cardTitle = document.createElement("h5");
        cardTitle.classList.add("card-title");
        cardTitle.innerText = task.name;
        const cardText = document.createElement("p");
        cardText.classList.add("card-text");
        cardText.innerText = task.description;
        cardText.classList.add("jani");
        const deleteButton = document.createElement("span");
        deleteButton.classList.add("btn-close");
        deleteButton.classList.add("deleteBtn");
        deleteButton.id = task.id;

        cardText.appendChild(deleteButton);
        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);
        cardItem.appendChild(cardBody);
        listItem.appendChild(cardItem);

        deleteButton.addEventListener("click", async () => {
            let response = await fetch(`https://localhost:7262/Tasks/delete/${listItem.id}`, { method: "DELETE" })
            console.log(response)
            listItem.style.animation = "slide-out 0.5s ease-in-out"
            setTimeout(() => {
                completedTaskList.removeChild(listItem)
            }, 400);
        })
        if (completedTaskList.children.length == 0) {
            completedTaskList.appendChild(listItem)
        }
        else {
            completedTaskList.insertBefore(listItem, completedTaskList.childNodes[0]);
        }

    }
}

taskAddBtn.addEventListener("click", async () => {

    if (taskAddName.value != "" && taskAddDesc.value != "") {

        let response = await fetch(`https://localhost:7262/Tasks/create`, { method: "PUT", body: JSON.stringify({ name: taskAddName.value, description: taskAddDesc.value }), headers: { "Content-Type": "application/json" } })
        // tasks = JSON.parse(localStorage.getItem("tasks")) ?? [];
        tasks = await (await fetch("https://localhost:7262/Tasks/tasks")).json()

        listItemAdder(await response.json())

        console.log()

        for (let i = 0; i < tasks.length; i++) {
            let elem = tasks[i];
            console.log(elem)
        }
        taskAddName.value = ""
        taskAddDesc.value = ""
    }
})

let clear = document.getElementById("clearTasks");

clear.addEventListener("click", function () {
    tasks = []
    // localStorage.setItem("tasks", JSON.stringify(tasks))

    console.log(tasks.length)
})