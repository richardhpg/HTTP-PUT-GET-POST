﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        Random rng = new Random();
        static List<User> _users = new List<User>() { new User("admin@admin.admin", "admin", "12345", 18, false, null, null) };

        [HttpPost]
        [Route("login:{user}&&{pass}")]

        public IActionResult Login(string user, string pass)
        {
            foreach (var item in _users)
            {
                if (item.name == user && item.password == pass)
                {
                    return Ok();
                }
                else
                {
                    return NotFound();
                }
            }

            return BadRequest();
        }

        [HttpGet]
        [Route("USERS")]

        public List<User> Users()
        {
            List<User> tempList = _users;
            foreach (var item in _users)
            {
                if (!item.Deleted)
                {
                    tempList.Add(item);
                }
            }

            return tempList;
        }

        [HttpGet]
        [Route("USERS{id}")]

        public IActionResult user1(Guid id)
        {
            foreach (var item in _users)
            {
                if (item.id == id)
                {
                    return Ok(item);
                }
            }
            return NotFound("user not found");
        }

        [HttpGet]
        [Route($"UserSpecific")]

        public IActionResult user2(string name, ushort age)
        {
            foreach (var user in _users)
            {
                if (user.name == name && user.age == age)
                {
                    return Ok(user);
                }
            }
            return NotFound("user no found");
        }

        [HttpPost]
        [Route("Create")]
        public User Create(string email, string name, string password)
        {
            int tempInt = rng.Next(ushort.MinValue + 1, ushort.MaxValue - 1);
            ushort tempUshort = Convert.ToUInt16(tempInt);
            bool deleted = false;
            DateTime? deleted_at = null;
            DateTime? updated_at = null;

            User newUser = new User(email, name, password, tempUshort, deleted, deleted_at, updated_at);

            _users.Add(newUser);

            return newUser;
        }

        [HttpPut]
        [Route("Update")]

        public IActionResult Update(Guid id, string email, string name, string password)
        {
            Guid tempId = _users[0].id;
            Console.WriteLine(tempId);

            foreach (var item in _users)
            {
                if (id == item.id && email != "")
                {
                    item.email = email;
                    item.Updated_at = DateTime.Now;
                }
                else
                {
                    return NotFound("error code 401");
                }
                if (id == item.id && name != "")
                {
                    item.name = name;
                    item.Updated_at = DateTime.Now;
                }
                else
                {
                    return NotFound("error code 401");
                }
                if (id == item.id && password != "")
                {
                    item.password = password;
                    item.Updated_at = DateTime.Now;
                }
                else
                {
                    return NotFound("error code 401");
                }
            }
            return Ok("code 200");
        }

        [HttpDelete]
        [Route("delete")]
        public IActionResult Delete(Guid id)
        {
            foreach (var item in _users)
            {
                if (item.id == id)
                {
                    item.Deleted = true;
                    return Ok("sikerült");
                }
            }
            return NotFound("Nincs ilyen elem");
        }
    }
}
