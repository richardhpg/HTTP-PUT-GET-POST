let menuButton = document.getElementById("menuColButton")
let logOut = document.getElementById("logOutBtn")
let menuCol = document.getElementById("menuCol")
let colStyle = window.getComputedStyle(menuCol)
let account = document.getElementById("felhasznalo")

menuButton.addEventListener("click", function()
{
    if (colStyle.display == "none") 
    {
        menuCol.style = "display:flex;"
    }
    else if (colStyle.display == "flex") 
    {
        menuCol.style = "display:none !important;"
    }
})

logOut.addEventListener("click", function()
{
    localStorage.removeItem("name")
})

function safetyNet()
{
    console.log(localStorage.getItem("name"))
    if (localStorage.getItem("name") != "admin" && localStorage.getItem("name") != "user") 
    {
        window.location.replace("index.html")
    }
}

function userOut()
{
    account.innerHTML = localStorage.getItem("name")
    document.getElementById("userOut").innerHTML = localStorage.getItem("name")
}